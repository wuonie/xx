#!/bin/bash
apt install \
    g++ make iputils-ping default-libmysqlclient-dev libpq-dev \
    libffi-dev libldap2-dev libsasl2-dev openssh-client sshpass pkg-config libxml2-dev \
    libxmlsec1-dev libxmlsec1-openssl libaio-dev freetds-dev freerdp2-dev
