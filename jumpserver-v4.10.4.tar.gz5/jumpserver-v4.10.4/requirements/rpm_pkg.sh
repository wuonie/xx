#!/bin/bash
yum -y install \
    gcc-c++ sshpass mariadb-devel openldap-devel openssh-clients libxml2-devel \
    xmlsec1-devel xmlsec1-openssl-devel libtool-ltdl-devel \
    postgresql-devel freerdp-devel
