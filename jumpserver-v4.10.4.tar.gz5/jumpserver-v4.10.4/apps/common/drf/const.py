CSV_FILE_ESCAPE_CHARS = ['=', '@', '0']
