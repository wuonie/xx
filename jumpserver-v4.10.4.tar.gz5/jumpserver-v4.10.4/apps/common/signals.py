# -*- coding: utf-8 -*-
#

from django.dispatch import Signal

django_ready = Signal()
