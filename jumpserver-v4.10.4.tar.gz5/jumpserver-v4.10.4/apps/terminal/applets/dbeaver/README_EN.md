## DBeaver

- When connecting to a database application, it is necessary to download the driver. You can either install it offline
  in advance or install the corresponding driver as prompted when connecting.
- Due to the implementation mechanism of autofill, the database password used for connection does not support the | character.
