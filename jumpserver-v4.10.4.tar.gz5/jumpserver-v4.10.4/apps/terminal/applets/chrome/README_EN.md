## Selenium Version

- Selenium == 4.4.0
- Chrome and ChromeDriver versions must match
- Driver [download address](https://chromedriver.chromium.org/downloads)

## ChangeLog

Refer to [ChangeLog](./ChangeLog) for some important updates.
