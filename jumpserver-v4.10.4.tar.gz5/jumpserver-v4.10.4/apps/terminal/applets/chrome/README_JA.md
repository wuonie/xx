## Selenium バージョン

- Selenium == 4.4.0
- Chrome と ChromeDriver のバージョンは一致している必要があります
- ドライバ [ダウンロードアドレス](https://chromedriver.chromium.org/downloads)

## 変更ログ

重要な更新については、[変更ログ](./ChangeLog) を参照してください
