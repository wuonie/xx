
## selenium 版本

- Selenium == 4.4.0
- Chrome 和 ChromeDriver 版本要匹配
- Driver [下载地址](https://chromedriver.chromium.org/downloads)

## ChangeLog

一些重要的更新记录参考 [ChangeLog](./ChangeLog)
