# 内置环境变量
BUILTIN_VARIABLES = {

}
