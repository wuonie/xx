__all__ = ['CommandInBlackListException']


class CommandInBlackListException(Exception):
    pass
